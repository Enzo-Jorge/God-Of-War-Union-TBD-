var postagemModel = require("../models/postagemModel");

function postar(req, res) {
    // Crie uma variável que vá recuperar os valores do arquivo cadastro.html
    var titulo = req.body.tituloServer;
    var conteudo = req.body.conteudoServer;
    var id = req.body.idServer;

    // Faça as validações dos valores
    if (titulo == undefined) {
        res.status(400).send("Seu titulo está undefined!");
    } else if (conteudo == undefined) {
        res.status(400).send("Seu conteudo está undefined!");
    } else {
        postagemModel.postar(titulo, conteudo, id
        )
            .then(
                function (resultado) {
                    res.json(resultado);
                }
            ).catch(
                function (erro) {
                    console.log(erro);
                    console.log(
                        "\nHouve um erro ao realizar a postagem! Erro: ",
                        erro.sqlMessage
                    );
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}

function AtualizarPosts(req, res) {
    postagemModel.AtualizarPosts()
    .then(function (resposta) {
        if(resposta.length >= 1) {
            res.status(200).json(resposta);
        }
    });
}

function comentar(req, res) {
    var conteudoComm = req.body.conteudoCommServer;
    var id = req.body.idServer;

    if (conteudoComm == undefined) {
        res.status(400).send("Seu conteudo está undefined!");
    } else {
        postagemModel.comentar(conteudoComm, id
        )
            .then(
                function (resultado) {
                    res.json(resultado);
                }
            ).catch(
                function (erro) {
                    console.log(erro);
                    console.log(
                        "\nHouve um erro ao realizar o comentário! Erro: ",
                        erro.sqlMessage
                    );
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}

module.exports = {
    postar,
    AtualizarPosts,
    comentar
}