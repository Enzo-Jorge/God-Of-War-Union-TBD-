var titulo_lista = ['God Of War', 'God Of War 2', 'God Of War 3', 'God Of War: Chains Of Olympus', 'God Of War: Ghost Of Sparta', 'God Of War: Ascension', 'God Of War (2018)', 'God Of War Ragnarok'];

var sinopse_lista = ['Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!']

var background_lista = ['https://i.pinimg.com/originals/78/8e/b3/788eb3fe3a2f75d898c900a425bab962.jpg', 'https://images3.alphacoders.com/428/4285.jpg', '', '', '', '', '', ''];

var distancia = 0;
var contagem = 0;

function avancar() {
    if(distancia > -700) {
    distancia -= 100;
    idimg1.style.marginLeft = `${distancia}%`;

    contagem++;

    // content.style.backgroundImage = `url(${background_lista[contagem]})`
    titulo_jogo.innerHTML = titulo_lista[contagem];
    sinopse_jogo.innerHTML = sinopse_lista[contagem];
    }
}

function retroceder() {
    if(distancia < 0) {
        distancia += 100;
        idimg1.style.marginLeft = `${distancia}%`;

        contagem--;
    titulo_jogo.innerHTML = titulo_lista[contagem];
    sinopse_jogo.innerHTML = sinopse_lista[contagem];
    }
}