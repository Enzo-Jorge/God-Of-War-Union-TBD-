var armas_lista = ['Lâminas do Caos', 'Lâmina de Ártemis', 'Lâminas de Atena', 'Martelo bárbaro', 'Lança do Destino', 'Lâmina do Olimpo', 'Lâminas do Exílio', 'Garras de Hades', 'Cestos de Neméia', 'Chicote de Nêmesis', 'Manopla de Zeus', 'Braços de Esparta', 'Machado Leviatã', 'Lança Draupinir'];

var descricao_lista = ['Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam et voluptas nobis aut voluptatem modi beatae consequatur quasi illum sed architecto sequi perspiciatis quidem, quisquam officiis minus autem quibusdam ducimus!']

var background_lista = ['https://i.pinimg.com/originals/78/8e/b3/788eb3fe3a2f75d898c900a425bab962.jpg', 'https://images3.alphacoders.com/428/4285.jpg', '', '', '', '', '', ''];

var distancia = 0;
var contagem = 0;

function avancar() {
    if(distancia > -1300) {
    distancia -= 100;
    idimg1.style.marginLeft = `${distancia}%`;

    contagem++;

    // content.style.backgroundImage = `url(${background_lista[contagem]})`
    arma_jogo.innerHTML = armas_lista[contagem];
    descricao_jogo.innerHTML = descricao_lista[contagem];
    }
}

function retroceder() {
    if(distancia < 0) {
        distancia += 100;
        idimg1.style.marginLeft = `${distancia}%`;

        contagem--;
        arma_jogo.innerHTML = armas_lista[contagem];
        descricao_jogo.innerHTML = descricao_lista[contagem];
    }
}