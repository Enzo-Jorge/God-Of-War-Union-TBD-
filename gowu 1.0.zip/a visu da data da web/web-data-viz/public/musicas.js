var titulo_lista = ['The Vengeful Spartar', 'Hydra Attacks', 'Climbing Net', 'Ares&#180; Battle', 'Colossus of Rhodes', 'The End Begins', 'The Glory of Sparta', 'The Bathhouse', 'Zeus vs Kratos', 'Overture', 'Main Menu GOW 3', 'Melody of Pandora', 'Hercules Fight', 'Brothers of Blood', 'Divine Retribution', 'God Of War', 'Lullaby of the Giants', 'The Reach of Your Godhood', 'God Of War Ragnarok', 'Remembering Faye', 'Blood Upon The Snow'];

var sinopse_lista = ['OST de God Of War 1', 'OST de God Of War 1', 'OST de God Of War 1', 'OST de God Of War 1', 'OST de God Of War 2', 'OST de God Of War 2', 'OST de God Of War 2', 'OST de God Of War 2', 'OST de God Of War 2', 'OST de God Of War 3', 'OST de God Of War 3', 'OST de God Of War 3', 'OST de God Of War 3', 'OST de God Of War 3', 'OST de God Of War 3', 'OST de God Of War (2018)', 'OST de God Of War (2018)', 'OST de God Of War (2018)', 'OST de God Of War Ragnarok', 'OST de God Of War Ragnarok', 'OST de God Of War Ragnarok']

var background_lista = ['https://i.pinimg.com/originals/78/8e/b3/788eb3fe3a2f75d898c900a425bab962.jpg', 'https://images3.alphacoders.com/428/4285.jpg', '', '', '', '', '', ''];

var distancia = 0;
var contagem = 0;

function avancar() {
    if(distancia > -2000) {
    distancia -= 100;
    idimg1.style.marginLeft = `${distancia}%`;

    contagem++;

    // content.style.backgroundImage = `url(${background_lista[contagem]})`
    titulo_jogo.innerHTML = titulo_lista[contagem];
    sinopse_jogo.innerHTML = sinopse_lista[contagem];
    }
}

function retroceder() {
    if(distancia < 0) {
        distancia += 100;
        idimg1.style.marginLeft = `${distancia}%`;

        contagem--;
    titulo_jogo.innerHTML = titulo_lista[contagem];
    sinopse_jogo.innerHTML = sinopse_lista[contagem];
    }
}